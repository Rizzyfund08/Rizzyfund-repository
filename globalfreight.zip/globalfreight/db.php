<?php

@define('DB_SERVER', 'localhost');
@define('DB_USERNAME', 'floydstille_cduser');
@define('DB_PASSWORD', 'v%tDch$~5htY1b%m');
@define('DB_NAME', 'floydstille_cdb');

 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

?>


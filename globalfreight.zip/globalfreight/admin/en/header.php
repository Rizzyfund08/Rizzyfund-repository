<?php 
session_start();
include '../../db.php';
include '../../config.php';
include '../../functions.php';

  if (isset($_SESSION['ADMINID'])) {
    $adminid = $_SESSION['ADMINID'];
    $select = mysqli_query($link, "SELECT * FROM admin WHERE id = '$adminid' ");
    $row = mysqli_fetch_assoc($select);
    $password = $row['password'];
    $username = $row['username'];
  }else{
    // header("location: ");
    echo "<script>window.location.href = 'login.php' </script>";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title> <?php echo $sitename ?> | Dashboard</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<!-- ================== BEGIN core-css ================== -->
	<link href="assets/css/vendor.min.css" rel="stylesheet">
	<link href="assets/css/app.min.css" rel="stylesheet">
	<!-- ================== END core-css ================== -->
	
	<!-- ================== BEGIN page-css ================== -->
	<link href="assets/plugins/jvectormap-next/jquery-jvectormap.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<!-- ================== END page-css ================== -->

</head>
<body>
	<!-- BEGIN #app -->
	<div id="app" class="app">
		<!-- BEGIN #header -->
		<div id="header" class="app-header">
			<!-- BEGIN desktop-toggler -->
			<div class="desktop-toggler">
				<button type="button" class="menu-toggler" data-toggle-class="app-sidebar-collapsed" data-toggle-target=".app">
					<span class="bar"></span>
					<span class="bar"></span>
				</button>
			</div>
			<!-- END desktop-toggler -->
			
			<!-- BEGIN mobile-toggler -->
			<div class="mobile-toggler">
				<button type="button" class="menu-toggler" data-toggle-class="app-sidebar-mobile-toggled" data-toggle-target=".app">
					<span class="bar"></span>
					<span class="bar"></span>
				</button>
			</div>
			<!-- END mobile-toggler -->
				
			<!-- BEGIN brand -->
			<div class="brand">
				<a href="index.html" class="brand-logo">
					droplet
				</a>
			</div>
			<!-- END brand -->
			
			<!-- BEGIN menu -->
			<div class="menu">
			
				
				<div class="menu-item dropdown dropdown-mobile-full">
					<a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
						<div class="menu-img online">
							<span class="menu-img-bg" style="background-image: url(assets/img/user/user.jpg)"></span>
						</div>
					
					</a>
					<div class="dropdown-menu dropdown-menu-end me-lg-3 mt-1 w-200px">
						<a class="dropdown-item d-flex align-items-center" href="account.php"><i class="far fa-user fa-fw fa-lg me-3"></i> Profile</a>

						<a class="dropdown-item d-flex align-items-center" href="settings.php"><i class="fa fa-sliders fa-fw fa-lg me-3"></i> Settings</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item d-flex align-items-center" href="logout.php"><i class="fa fa-arrow-right-from-bracket fa-fw fa-lg me-3"></i> Logout</a>
					</div>
				</div>
			</div>
			<!-- END menu -->
			
			<!-- BEGIN menu-search -->
			<form class="menu-search" method="POST" name="header_search_form">
				<div class="menu-search-container">
					<div class="menu-search-icon"><i class="bi bi-search"></i></div>
					<div class="menu-search-input">
						<input type="text" class="form-control form-control-lg" placeholder="Search menu...">
					</div>
					<div class="menu-search-icon">
						<a href="#" data-toggle-class="app-header-menu-search-toggled" data-toggle-target=".app"><i class="bi bi-x-lg"></i></a>
					</div>
				</div>
			</form>
			<!-- END menu-search -->
		</div>
		<!-- END #header -->
		
		<!-- BEGIN #sidebar -->
		<div id="sidebar" class="app-sidebar">
			<!-- BEGIN scrollbar -->
			<div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
				<!-- BEGIN menu -->
				<div class="menu">
					<div class="menu-profile">
						<a href="javascript:;" class="menu-profile-link" data-bs-toggle="dropdown">
							<div class="menu-profile-cover with-shadow"></div>
							<div class="menu-profile-image">
								<div class="menu-profile-img" style="background-image: url(assets/img/user/user.jpg)"></div>
							</div>
							<div class="menu-profile-info">
								<div class="d-flex align-items-center">
									<div class="flex-grow-1 fw-bold">
										Administrator
									</div>
									<div class="ms-auto"><i class="fa fa-chevron-down"></i></div>
								</div>
								<small><span>admin@mail.com</span></small>
							</div>
						</a>
						<div class="dropdown-menu dropdown-menu-end me-lg-3 mt-1 w-200px">
							<a class="dropdown-item d-flex align-items-center" href="account.php"><i class="far fa-user fa-fw fa-lg me-3"></i> Profile</a>
					
						
							<a class="dropdown-item d-flex align-items-center" href="settings.php"><i class="fa fa-sliders fa-fw fa-lg me-3"></i> Settings</a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item d-flex align-items-center" href="logout.php"><i class="fa fa-arrow-right-from-bracket fa-fw fa-lg me-3"></i> Logout</a>
						</div>
					</div>
					<div class="menu-header">Navigation</div>
					<div class="menu-item active">
						<a href="dashboard.php" class="menu-link">
							<span class="menu-icon"><i class="fa fa-qrcode"></i></span>
							<span class="menu-text">Dashboard</span>
						</a>
					</div>
					<div class="menu-item">
						<a href="addtracking.php" class="menu-link">
							<span class="menu-icon"><i class="fa fa-chart-bar"></i></span>
							<span class="menu-text">Add Tracking</span>
						</a>
					</div>
					
						<div class="menu-item">
						<a href="settings.php" class="menu-link">
							<span class="menu-icon"><i class="fa fa-sliders"></i></span>
							<span class="menu-text">Settings</span>
						</a>
					</div>
					
					
						<div class="menu-item">
						<a href="shipping_settings.php" class="menu-link">
							<span class="menu-icon"><i class="fa fa-gem"></i></span>
							<span class="menu-text">Shipping Settings</span>
						</a>
							</div>
							
							
								<div class="menu-item">
						<a href="account.php" class="menu-link">
							<span class="menu-icon"><i class="fab fa-slack"></i></span>
							<span class="menu-text">Account</span>
						</a>
					</div>
					
								<div class="menu-item">
						<a href="logout.php" class="menu-link">
							<span class="menu-icon"><i class="fab fa-slack"></i></span>
							<span class="menu-text">Logout</span>
						</a>
					</div>
					
					
				
				</div>
			
			</div>
			<!-- END scrollbar -->
		</div>
		<!-- END #sidebar -->
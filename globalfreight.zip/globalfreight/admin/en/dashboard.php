<?php 
include 'header.php';

if (isset($_POST['delete'])) {
    $image = $_POST['image'];
    $tnumb = $_POST['tnumb'];
    $delete = mysqli_query($link, "DELETE FROM tracking WHERE tracking_number = '$tnumb' ");
    if ($tnumb) {
        mysqli_query($link, "DELETE FROM track_update WHERE track_num = '$tnumb' ");
        unlink("../uploads/".$image);
        echo "<script>alert('Deleted Successfully');window.location.href = 'dashboard.php' </script>";
    }
}
?>
            
        <!-- BEGIN mobile-sidebar-backdrop -->
        <button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
        <!-- END mobile-sidebar-backdrop -->
        
        <!-- BEGIN #content -->
        <div id="content" class="app-content">
            <!-- BEGIN container -->
            <div class="container">
                <!-- BEGIN row -->
                <div class="row justify-content-center">
                    <!-- BEGIN col-10 -->
                    <div class="col-xl-12">
                        <!-- BEGIN row -->
                        <div class="row">
                            <!-- BEGIN col-12 -->
                            <div class="col-xl-12">
                            
                                
                            
                                <hr class="mb-4">
                                
                                <!-- BEGIN #datatable -->
                                <div id="datatable" class="mb-5">
                                    <h4>TRACKERS</h4>
                                
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table id="datatableDefault" class="table table-striped table-bordered align-middle nowrap" style="width:100%">
                                                    <thead class="bg-light">
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Image</th>
                                                            <th>Tracking Number</th>
                                                            <th>Status</th>
                                                            <th>Date Added</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php 
                                                        $i = 0;
                                                            $tr = mysqli_query($link, "SELECT * FROM tracking ");
                                                            if (mysqli_num_rows($tr) > 0 ) {
                                                                while ($row = mysqli_fetch_assoc($tr)) {
                                                                    $i++
                                                        ?>
                                                        <form method="post" action="dashboard.php">
                                                            <input type="hidden" name="tnumb" value="<?php echo $row['tracking_number'] ?>">
                                                            <tr>
                                                                <td><?php echo $i; ?></td>
                                                                <td><img style="height: 60px;width: 60px; object-fit: cover;" src="../../uploads/<?php echo $row['image'] ?>" class="img-thumbnail"></td>
                                                                <td><b><?php echo $row['tracking_number'] ?></b></td>
                                                                <td><span class="badge bg-<?php echo ($row['status'] == 'Delivered') ? 'success' : 'warning'; ?>"><?php echo $row['status'] ?></span></td>
                                                                <td><b><?php echo $row['date'] ?></b></td>
                                                                <td>
                                                                    <div class="btn-group" role="group">
                                                                        <a href="edit-tracking.php?num=<?php echo $row['tracking_number'] ?>" class="btn btn-sm btn-primary" title="Edit"><i class="fa fa-edit"></i></a>
                                                                        <button type="submit" name="delete" onclick="return confirm('Do you really want to delete this?')" class="btn btn-sm btn-danger" title="Delete"><i class="fa fa-trash"></i></button>
                                                                        <button type="button" onclick="copyContent('<?php echo $row['tracking_number'] ?>')" class="btn btn-sm btn-info" title="Copy"><i class="fa fa-copy"></i></button>
                                                                        <a class="btn btn-sm btn-warning" href="view-details.php?num=<?php echo $row['tracking_number'] ?>" title="Details"><i class="fa fa-eye"></i></a>
                                                                        <a class="btn btn-sm btn-secondary" href="view-updates.php?num=<?php echo $row['tracking_number'] ?>" title="Updates"><i class="fa fa-history"></i></a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <input type="hidden" name="image" value="<?php echo $row['image'] ?>">
                                                        </form>
                                                        <?php }} ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="hljs-container rounded-bottom">
                                            <pre><code class="xml" data-url="assets/data/table-plugins/code-1.json"></code></pre>
                                        </div>
                                    </div>
                                </div>
                                <!-- END #datatable -->
                                
                            </div>
                            <!-- END col-12 -->
                        </div>
                        <!-- END row -->
                    </div>
                    <!-- END col-10 -->
                </div>
                <!-- END row -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #content -->
        
        <script>
            function copyContent(text) {
                navigator.clipboard.writeText(text).then(function() {
                    toastr.success("Copied tracking number: " + text);
                }, function() {
                    toastr.error("Failed to copy tracking number");
                });
            }
        </script>

<?php include 'footer.php'; ?>
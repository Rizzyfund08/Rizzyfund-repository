<?php  
include 'header.php';

if (isset($_POST['save-general'])) {
	$site_name = trim($_POST['site_name']);
	$sitetitle = trim($_POST['sitetitle']);
	$siteurl = trim($_POST['siteurl']);

	if (!empty($site_name) && !empty($sitetitle)) {
		$sql = mysqli_query($link, "UPDATE settings SET `site_url` = '$siteurl', `sitename`='$site_name',`site_title`='$sitetitle' WHERE id = 1 ");
		if ($sql) {
			echo "<script>
			alert('Settings saved');
			window.location.href = 'settings.php';
			</script>";
		}
	}
}
?>
			
		<!-- BEGIN mobile-sidebar-backdrop -->
		<button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
		<!-- END mobile-sidebar-backdrop -->
		
		<!-- BEGIN #content -->
		<div id="content" class="app-content">
			<!-- BEGIN container -->
			<div class="container">
				<!-- BEGIN row -->
				<div class="row justify-content-center">
					<!-- BEGIN col-10 -->
					<div class="col-xl-10">
						<!-- BEGIN row -->
						<div class="row">
							<!-- BEGIN col-9 -->
							<div class="col-xl-9">
							
								
							
								<hr class="mb-4">
								
								<!-- BEGIN #formControls -->
								<div id="formControls" class="mb-5">
									<h4>Settings</h4>
									
							        <div class="card">
            <div class="card-body">
                
        

<form action="" method="POST">
        <div class="personal-informations-from">
            <!-- Sender Information -->
            <div class="personal-informations-from-item">
                <div class="personal-informations-from-item-inner">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="sname" class="form-label">Site Name</label>
                            <input type="text" class="form-control" name="site_name" value="<?php echo $sitename ?>" required>
                        </div>
                     
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="smail" class="form-label">Site Email</label>
                            <input type="text" class="form-control" name="sitetitle" value="<?php echo $site_title ?>" required>
                        </div>

                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="saddress" class="form-label">Site url</label>
                            <input type="text" class="form-control" name="siteurl" value="<?php echo $site_url ?>" required>
                        </div>
                    </div>
                </div>
            </div>
        <br><br>
            <!-- Submit Button -->
            <div class="personal-informations-from-btn">
                    <button style='margin-top: 2px; background-color: blue; padding: 10px; border: none; border-radius: 5px' type="submit" name="save-general" class="btn-one">Save</button>
            </div>
        </form>
        </div>
            </div>
        </div>
								</div>
								<!-- END #formControls -->
								
							
								
							
								
								
					
							</div>
							<!-- END col-9-->
							
							
						</div>
						<!-- END row -->
					</div>
					<!-- END col-10 -->
				</div>
				<!-- END row -->
			</div>
			<!-- END container -->
		</div>
		<!-- END #content -->
		
	<?php include 'footer.php'; ?>
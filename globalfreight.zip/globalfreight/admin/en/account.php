<?php 
	include 'header.php';

	if (isset($_POST['save'])) {
		$adminuser = text_input($_POST['username']);
		$adminpass = text_input($_POST['password']);
		if (empty($adminuser) || empty($adminpass)) {
			echo "<script>alert('Empty Field(s)')</script>";
		}else{
			mysqli_query($link, "UPDATE admin SET username = '$adminuser', password = '$adminpass' WHERE username = '$username' ");
			echo "<script>
			alert('Successfully updated');
			window.location.href = 'account.php';
			</script>";
			exit();
		}
	}

	function text_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
	}
?>
			
		<!-- BEGIN mobile-sidebar-backdrop -->
		<button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
		<!-- END mobile-sidebar-backdrop -->
		
		<!-- BEGIN #content -->
		<div id="content" class="app-content">
			<!-- BEGIN container -->
			<div class="container">
				<!-- BEGIN row -->
				<div class="row justify-content-center">
					<!-- BEGIN col-10 -->
					<div class="col-xl-10">
						<!-- BEGIN row -->
						<div class="row">
							<!-- BEGIN col-9 -->
							<div class="col-xl-9">
							
								
							
								<hr class="mb-4">
								
								<!-- BEGIN #formControls -->
								<div id="formControls" class="mb-5">
									<h4>Admin Details</h4>
									
							        <div class="card">
            <div class="card-body">
                
        

   <form action="" method="POST">
        <div class="personal-informations-from">
            <!-- Sender Information -->
            <div class="personal-informations-from-item">
                <div class="personal-informations-from-item-inner">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="sname" class="form-label">Admin Name</label>
                            <input type="text" class="form-control" name="username" value="<?php echo $username ?>" required>
                        </div>
                     
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="smail" class="form-label">Password</label>
                            <input type="text" class="form-control" name="password" value="<?php echo $password ?>" required>
                        </div>

                      
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="personal-informations-from-btn">
                    <button style='margin-top: 2px; background-color: blue; padding: 10px; border: none; border-radius: 5px' type="submit" name="save-ship" class="btn-one">Save</button>
            </div>
        </form>
        
        </div>
            </div>
        </div>
								</div>
								<!-- END #formControls -->
								
							
								
							
								
								
					
							</div>
							<!-- END col-9-->
							
							
						</div>
						<!-- END row -->
					</div>
					<!-- END col-10 -->
				</div>
				<!-- END row -->
			</div>
			<!-- END container -->
		</div>
		<!-- END #content -->
		
	<?php include 'footer.php'; ?>
<?php  
include 'header.php';

if (isset($_POST['save-ship'])) {
	$prefix = trim($_POST['prefix']);
	$trace = trim($_POST['trace']);
	$print = trim($_POST['print']);
	$map = trim($_POST['show_map']);
	$terms = trim($_POST['terms']);

	if (!empty($prefix) && !empty($trace) && !empty($print) && !empty($show_map) && !empty($terms)) {
		$sql = mysqli_query($link, "UPDATE settings SET `track_prefix`='$prefix',`track_num`='$trace',`invoice_terms`='$terms',`allow_print`='$print',`show_map`='$map' WHERE id = 1 ");
		if ($sql) {
			echo "<script>
			alert('Settings saved');
			window.location.href = 'shipping_settings.php';
			</script>";
		}
	}
}

?>
			
		<!-- BEGIN mobile-sidebar-backdrop -->
		<button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
		<!-- END mobile-sidebar-backdrop -->
		
		<!-- BEGIN #content -->
		<div id="content" class="app-content">
			<!-- BEGIN container -->
			<div class="container">
				<!-- BEGIN row -->
				<div class="row justify-content-center">
					<!-- BEGIN col-10 -->
					<div class="col-xl-10">
						<!-- BEGIN row -->
						<div class="row">
							<!-- BEGIN col-9 -->
							<div class="col-xl-9">
							
								
							
								<hr class="mb-4">
								
								<!-- BEGIN #formControls -->
								<div id="formControls" class="mb-5">
									<h4>Shipping Settings</h4>
									
							        <div class="card">
            <div class="card-body">
                
        

 <form action="" method="POST">
        <div class="personal-informations-from">
            <!-- Sender Information -->
            <div class="personal-informations-from-item">
                <div class="personal-informations-from-item-inner">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="sname" class="form-label">Prefix</label>
                            <input type="text" class="form-control" name="prefix" value="<?php echo $track_prefix ?>" required>
                        </div>
                     
                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="smail" class="form-label">Trace</label>
                            <input type="text" class="form-control" name="trace" value="<?php echo $track_num ?>" required>
                        </div>

                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="saddress" class="form-label">Print</label>
                            <input type="text" class="form-control" name="print" value="<?php echo $allow_print ?>" required>
                        </div>

                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="saddress" class="form-label">Show map</label>
                            <input type="text" class="form-control" name="show_map" value="<?php echo $show_map ?>" required>
                        </div>

                        <div class="col-12 col-md-12 col-lg-12">
                            <label for="saddress" class="form-label">Terms</label>
                            <input type="text" class="form-control" name="terms" value="<?php echo $invoice_terms ?>" required>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="personal-informations-from-btn">
                    <button style='margin-top: 2px; background-color: blue; padding: 10px; border: none; border-radius: 5px' type="submit" name="save-ship" class="btn-one">Save</button>
            </div>
        </form>
        </div>
            </div>
        </div>
								</div>
								<!-- END #formControls -->
								
							
								
							
								
								
					
							</div>
							<!-- END col-9-->
							
							
						</div>
						<!-- END row -->
					</div>
					<!-- END col-10 -->
				</div>
				<!-- END row -->
			</div>
			<!-- END container -->
		</div>
		<!-- END #content -->
		
	<?php include 'footer.php'; ?>
<?php 
include 'header.php';
include '../db.php';
	
if (isset($_GET['num'])) {
    $tnumbs = $_GET['num'];
    $select = mysqli_query($link, "SELECT * FROM tracking WHERE tracking_number = '$tnumbs' ");
    if (mysqli_num_rows($select) > 0) {
      $row = mysqli_fetch_assoc($select);
        $senders_name = $row['sender_name'];  
         $senders_contact = $row['sender_contact'];  
         $senders_mail = $row['sender_email'];  
         $senders_address = $row['sender_address'];
         $receivers_name = $row['receiver_name'];  
         $receivers_contact = $row['receiver_contact'];  
         $receivers_mail = $row['receiver_email'];  
         $receivers_address = $row['receiver_address'];
         $statuss = $row['status'];  
         $dispatch_l = $row['dispatch_location'];  
         $dispatchh = $row['dispatch_date'];  
         $deliveryy = $row['delivery_date'];
         $current_loc = $row['current_location'];
         $desc = $row['pdesc'];
         $carrier = $row['carrier'];
         $carrier_ref = $row['carrier_ref'];
         $weight = $row['weight'];
         $payment_mode = $row['payment_mode'];
         $ship_mode = $row['ship_mode'];
         $quantity = $row['quantity'];
         $delivery_time = $row['delivery_time'];
         $image = $row['image'];
         $destination = $row['destination'];

    }else{
      echo "<script>window.location.href = 'dashboard.php'; </script>";
    }
  }else{
    echo "<script>window.location.href = 'dashboard.php'; </script>";
  }

?>
			
		<!-- BEGIN mobile-sidebar-backdrop -->
		<button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>
		<!-- END mobile-sidebar-backdrop -->
		
		<!-- BEGIN #content -->
		<div id="content" class="app-content">
			<!-- BEGIN container -->
			<div class="container">
				<!-- BEGIN row -->
				<div class="row justify-content-center">
					<!-- BEGIN col-10 -->
					<div class="col-xl-10">
						<!-- BEGIN row -->
						<div class="row">
							<!-- BEGIN col-9 -->
							<div class="col-xl-9">
							
								
							
								<hr class="mb-4">
								
								<!-- BEGIN #formControls -->
								<div id="formControls" class="mb-5">
									<h4>Admin Details</h4>
									
							        <div class="card">
            <div class="card-body">
                
        

   <form action="" method="POST" enctype="multipart/form-data">
                                        <!-- Sender Information -->
                                        <h5>Sender Information</h5>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="sname">Sender's Name</label>
                                                <input type="text" name="sname" id="sname" class="form-control" value="<?php echo $senders_name; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="scontact">Sender's Contact</label>
                                                <input type="text" name="scontact" id="scontact" class="form-control" value="<?php echo $senders_contact; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="smail">Sender's Email</label>
                                                <input type="email" name="smail" id="smail" class="form-control" value="<?php echo $senders_mail; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="saddress">Sender's Address</label>
                                                <input type="text" name="saddress" id="saddress" class="form-control" value="<?php echo $senders_address; ?>">
                                            </div>
                                        </div>

                                        <!-- Receiver Information -->
                                        <h5>Receiver Information</h5>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="rname">Receiver's Name</label>
                                                <input type="text" name="rname" id="rname" class="form-control" value="<?php echo $receivers_name; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="rcontact">Receiver's Contact</label>
                                                <input type="text" name="rcontact" id="rcontact" class="form-control" value="<?php echo $receivers_contact; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="rmail">Receiver's Email</label>
                                                <input type="email" name="rmail" id="rmail" class="form-control" value="<?php echo $receivers_mail; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="raddress">Receiver's Address</label>
                                                <input type="text" name="raddress" id="raddress" class="form-control" value="<?php echo $receivers_address; ?>">
                                            </div>
                                        </div>

                                        <!-- Package Information -->
                                        <h5>Package Information</h5>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="status">Status</label>
                                                <select name="status" class="form-control">
                                                    <option value="Pending" <?php echo $statuss == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="Active" <?php echo $statuss == 'Active' ? 'selected' : ''; ?>>Active</option>
                                                    <option value="Inactive" <?php echo $statuss == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                                                    <option value="Picked Up" <?php echo $statuss == 'Picked Up' ? 'selected' : ''; ?>>Picked Up</option>
                                                    <option value="Arrived" <?php echo $statuss == 'Arrived' ? 'selected' : ''; ?>>Arrived</option>
                                                    <option value="Delivered" <?php echo $statuss == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                                    <option value="On hold" <?php echo $statuss == 'On hold' ? 'selected' : ''; ?>>On Hold</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="dispatchl">Dispatch Location</label>
                                                <input type="text" name="dispatchl" class="form-control" value="<?php echo $dispatch_l; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="dispatchh">Dispatch Date</label>
                                                <input type="date" name="dispatchh" class="form-control" value="<?php echo $dispatchh; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="deliveryy">Delivery Date</label>
                                                <input type="date" name="deliveryy" class="form-control" value="<?php echo $deliveryy; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="desc">Description</label>
                                                <input type="text" name="desc" class="form-control" value="<?php echo $desc; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="carrier">Carrier</label>
                                                <input type="text" name="carrier" class="form-control" value="<?php echo $carrier; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="carrier_ref">Carrier Reference</label>
                                                <input type="text" name="carrier_ref" class="form-control" value="<?php echo $carrier_ref; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="weight">Weight</label>
                                                <input type="number" step="0.01" name="weight" class="form-control" value="<?php echo $weight; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="payment_mode">Payment Mode</label>
                                                <input type="text" name="payment_mode" class="form-control" value="<?php echo $payment_mode; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="ship_mode">Shipping Mode</label>
                                                <input type="text" name="ship_mode" class="form-control" value="<?php echo $ship_mode; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="quantity">Quantity</label>
                                                <input type="text" name="quantity" class="form-control" value="<?php echo $quantity; ?>">
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="delivery_time">Delivery Time</label>
                                                <input type="time" name="delivery_time" class="form-control" value="<?php echo $delivery_time; ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="destination">Destination</label>
                                                <input type="text" name="destination" class="form-control" value="<?php echo $destination; ?>">
                                            </div>
                                            
                               
                                       </div>
                                       <center>
                                        <label for="Packageimage">Package Image</label>
                                             <div class="form-group col-md-12">
                                             
                                             <img src="../../uploads/<?php echo $image; ?>" alt="Centered Image" class="center-image">
                                            </div>
                                       </center>
                                    </form>
        
        </div>
            </div>
        </div>
								</div>
								<!-- END #formControls -->
								
							
								
							
								
								
					
							</div>
							<!-- END col-9-->
							
							
						</div>
						<!-- END row -->
					</div>
					<!-- END col-10 -->
				</div>
				<!-- END row -->
			</div>
			<!-- END container -->
		</div>
		<!-- END #content -->
		
	<?php include 'footer.php'; ?>
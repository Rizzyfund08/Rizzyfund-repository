
		<!-- BEGIN btn-scroll-top -->
		<a href="#" data-toggle="scroll-to-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #app -->
	
	<!-- ================== BEGIN core-js ================== -->
	<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/vendor.min.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/js/app.min.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<!-- ================== END core-js ================== -->
	
	<!-- ================== BEGIN page-js ================== -->
	<script src="assets/plugins/jvectormap-next/jquery-jvectormap.min.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/plugins/jvectormap-content/world-mill.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/plugins/apexcharts/dist/apexcharts.min.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/plugins/moment/min/moment.min.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/plugins/bootstrap-daterangepicker/daterangepicker.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script src="assets/js/demo/dashboard.demo.js" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<!-- ================== END page-js ================== -->
	
	
	<script async="" src="../gtag/js?id=G-Y3Q0VGQKY3" type="7c59fc482463e7b64c1be16f-text/javascript"></script>
	<script type="7c59fc482463e7b64c1be16f-text/javascript">
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
	
		gtag('config', 'G-Y3Q0VGQKY3');
	</script>
<script src="../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="7c59fc482463e7b64c1be16f-|49" defer=""></script></body>
</html>

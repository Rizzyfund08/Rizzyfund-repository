/*
Template Name: Droplet - Responsive Bootstrap 5 Admin Template
Version: 6.0.0
Author: Sean Ngu
Website: http://www.seantheme.com/droplet/
*/


/* Controller
------------------------------------------------ */
$(document).ready(function() {
	var scrollSpy = new bootstrap.ScrollSpy(document.body, {
		target: '#sidebar-bootstrap',
		offset: 200
	})
});
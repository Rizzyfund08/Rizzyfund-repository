-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 02, 2025 at 02:25 PM
-- Server version: 10.11.13-MariaDB
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtechscom_globalfrieghtdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `site_title` varchar(255) NOT NULL,
  `site_url` varchar(255) NOT NULL,
  `track_prefix` varchar(255) NOT NULL,
  `track_num` varchar(255) NOT NULL,
  `invoice_terms` text NOT NULL,
  `allow_print` enum('Yes','No','','') NOT NULL,
  `show_map` enum('Yes','No','','') NOT NULL,
  `email_name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `mail_track_update` enum('Yes','No','','') NOT NULL,
  `mail_track_save` enum('Yes','No','','') NOT NULL,
  `site_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `sitename`, `site_title`, `site_url`, `track_prefix`, `track_num`, `invoice_terms`, `allow_print`, `show_map`, `email_name`, `email_address`, `mail_track_update`, `mail_track_save`, `site_address`) VALUES
(1, 'Global Freight', 'mail@devionicsolutions.com.ng', 'https://devionicsolutions.com.ng/globalfreight/', 'AR', '7', 'terms', 'Yes', 'Yes', 'Crest', 'info@globalfreight.com', 'Yes', 'Yes', 'John Doe 742 Evergreen Terrace Springfield, IL 62704 United States');

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE `tracking` (
  `id` int(11) NOT NULL,
  `tracking_number` varchar(255) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `sender_contact` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `sender_address` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `dispatch_location` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_contact` varchar(255) NOT NULL,
  `receiver_address` varchar(255) NOT NULL,
  `dispatch_date` varchar(255) NOT NULL,
  `delivery_date` varchar(255) NOT NULL,
  `pdesc` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `current_location` varchar(255) DEFAULT NULL,
  `carrier` varchar(255) NOT NULL,
  `carrier_ref` varchar(255) NOT NULL,
  `ship_mode` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `total_f` varchar(255) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `delivery_time` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'Latitude of dispatch location',
  `longitude` decimal(10,8) DEFAULT NULL COMMENT 'Longitude of dispatch location',
  `destination_lat` decimal(10,8) DEFAULT NULL COMMENT 'Latitude of destination',
  `destination_lng` decimal(10,8) DEFAULT NULL COMMENT 'Longitude of destination',
  `requires_permit` tinyint(1) DEFAULT 0 COMMENT '1 if shipment requires customs permit',
  `permit_type` varchar(100) DEFAULT NULL COMMENT 'Type of required permit/documentation'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tracking`
--

INSERT INTO `tracking` (`id`, `tracking_number`, `sender_name`, `sender_contact`, `sender_email`, `sender_address`, `status`, `dispatch_location`, `receiver_email`, `receiver_name`, `receiver_contact`, `receiver_address`, `dispatch_date`, `delivery_date`, `pdesc`, `destination`, `current_location`, `carrier`, `carrier_ref`, `ship_mode`, `weight`, `quantity`, `payment_mode`, `total_f`, `image`, `delivery_time`, `date`, `latitude`, `longitude`, `destination_lat`, `destination_lng`, `requires_permit`, `permit_type`) VALUES
(13, '1234567890', 'Loretta D. Greer', '304-872-9279', 'LorettaDGreer@rhyta.com', '2868 Kelly Drive Summersville', 'On hold', '1600 Amphitheatre Parkway, Mountain View, CA', 'MayDRivas@armyspy.com', 'May D. Rivas', '901-522-0004', '3553 Lightning Point Drive Memphis', '2025-05-17', '2025-05-30', 'an image', 'Great Russell St, London, WC1B 3DG, United Kingdom', '42 Willow Crescent Sheffield S10 3LT', 'dhl', '23532523', 'air', '12', '1', 'cash', '100', 'CR-05-536847.png', '12:42', '2025-05-17 13:17:35', 53.45888960, -1.46957390, 51.51789340, -0.12717940, 1, 'clerance Document');

-- --------------------------------------------------------

--
-- Table structure for table `track_update`
--

CREATE TABLE `track_update` (
  `id` int(11) NOT NULL,
  `track_num` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `current_location` varchar(255) NOT NULL,
  `shiping_cost` varchar(255) NOT NULL,
  `clearance_cost` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'Latitude of update location',
  `longitude` decimal(10,8) DEFAULT NULL COMMENT 'Longitude of update location'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `track_update`
--

INSERT INTO `track_update` (`id`, `track_num`, `status`, `date`, `time`, `note`, `current_location`, `shiping_cost`, `clearance_cost`, `updated_at`, `latitude`, `longitude`) VALUES
(30, 'CR-05-536847', 'Delivered', '2025-05-17', '12:59', 'test', '42 Willow Crescent Sheffield S10 3LT', '12', '12', '2025-05-17 13:59:49', 53.45888960, -1.46957390),
(31, '1234567890', 'On hold', '2025-05-26', '15:56', 'on hold', '42 Willow Crescent Sheffield S10 3LT', '', '', '2025-05-26 16:56:52', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tracking`
--
ALTER TABLE `tracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_update`
--
ALTER TABLE `track_update`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tracking`
--
ALTER TABLE `tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `track_update`
--
ALTER TABLE `track_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

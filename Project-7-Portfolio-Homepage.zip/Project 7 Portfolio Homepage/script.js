// Define basic code templates for each language
const codeTemplates = {
    html: `<!DOCTYPE html>
<html>
<head>
    <title>Hello World</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Hello World!</h1>
    <p>Welcome to my website</p>
    <script src="script.js"></script>
</body>
</html>`,
    css: `body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f0f0f0;
}

h1 {
    color: #333;
}`,
    js: `// JavaScript code
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded');
    
    // Add your JavaScript here
    const button = document.getElementById('demoBtn');
    button.addEventListener('click', () => {
        alert('Button clicked!');
    });
    
    // Update time
    const timeElement = document.getElementById('currentTime');
    timeElement.textContent = new Date().toLocaleTimeString();
    setInterval(() => {
        timeElement.textContent = new Date().toLocaleTimeString();
    }, 1000);
});`,
    python: `# Python code
print("Hello, World!")

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

print(factorial(5))`,
    c: `// C code
#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}`,
    cpp: `// C++ code
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}`,
    java: `// Java code
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`,
    php: `<?php
// PHP code
echo "Hello, World!";
?>`,
    ruby: `# Ruby code
puts "Hello, World!"`,
    swift: `// Swift code
import Swift

print("Hello, World!")`,
    typescript: `// TypeScript code
const message: string = "Hello, World!";
console.log(message);`,
    go: `// Go code
package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}`,
    rust: `// Rust code
fn main() {
    println!("Hello, World!");
}`,
    kotlin: `// Kotlin code
fun main() {
    println("Hello, World!")
}`,
    dart: `// Dart code
void main() {
  print('Hello, World!');
}`,
    scala: `// Scala code
object HelloWorld {
  def main(args: Array[String]): Unit = {
    println("Hello, World!")
  }
}`
};

// Define expected outputs for each language template
const languageOutputs = {
    python: "Hello, World!\n120",
    c: "Hello, World!",
    cpp: "Hello, World!",
    java: "Hello, World!",
    php: "Hello, World!",
    ruby: "Hello, World!",
    swift: "Hello, World!",
    typescript: "Hello, World!",
    go: "Hello, World!",
    rust: "Hello, World!",
    kotlin: "Hello, World!",
    dart: "Hello, World!",
    scala: "Hello, World!",
    javascript: "Page loaded\nButton clicked!"
};

// Initialize syntax highlighting
hljs.highlightAll();

// Store current code for each file
let currentHTML = codeTemplates.html;
let currentCSS = codeTemplates.css;
let currentJS = codeTemplates.js;
let currentLanguage = 'html';

// DOM Elements
const langBtn = document.querySelector('.lang-btn');
const langDropdown = document.querySelector('.lang-dropdown');
const tabs = document.querySelectorAll('.tab');
const fileItems = document.querySelectorAll('.file-item');
const runBtn = document.querySelector('.btn-run');
const outputContent = document.querySelector('.output-content');
const clearOutputBtn = document.getElementById('clear-output');
const languageCards = document.querySelectorAll('.language-card');
const themeToggle = document.querySelector('.theme-toggle');
const htmlCode = document.getElementById('html-code');
const formatBtn = document.getElementById('format-btn');
const copyBtn = document.getElementById('copy-btn');
const clearBtn = document.getElementById('clear-btn');
const fullscreenBtn = document.querySelector('.fullscreen-btn');
const outputContainer = document.querySelector('.output-container');

// Make code block editable
htmlCode.contentEditable = true;

// Initialize editor
updateHighlighting();

// Toggle language dropdown
langBtn.addEventListener('click', () => {
    langDropdown.classList.toggle('active');
});

// Toggle theme
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');
    const isLightTheme = document.body.classList.contains('light-theme');
    themeToggle.innerHTML = isLightTheme ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    updateHighlighting();
});

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
    if (!langBtn.contains(e.target)) {
        langDropdown.classList.remove('active');
    }
});

// Tab switching
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        
        // Update editor content based on selected tab
        if (tab.textContent.includes('index.html')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'index.html';
            document.querySelector('.editor-title i').className = 'fab fa-html5';
            document.querySelector('.editor-title i').style.color = '#e34c26';
            htmlCode.textContent = currentHTML;
        } else if (tab.textContent.includes('styles.css')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'styles.css';
            document.querySelector('.editor-title i').className = 'fab fa-css3-alt';
            document.querySelector('.editor-title i').style.color = '#264de4';
            htmlCode.textContent = currentCSS;
        } else if (tab.textContent.includes('script.js')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'script.js';
            document.querySelector('.editor-title i').className = 'fab fa-js';
            document.querySelector('.editor-title i').style.color = '#f0db4f';
            htmlCode.textContent = currentJS;
        }
        
        updateHighlighting();
    });
});

// File switching
fileItems.forEach(item => {
    item.addEventListener('click', () => {
        fileItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        
        // Update editor content based on selected file
        if (item.textContent.includes('index.html')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'index.html';
            document.querySelector('.editor-title i').className = 'fab fa-html5';
            document.querySelector('.editor-title i').style.color = '#e34c26';
            htmlCode.textContent = currentHTML;
        } else if (item.textContent.includes('styles.css')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'styles.css';
            document.querySelector('.editor-title i').className = 'fab fa-css3-alt';
            document.querySelector('.editor-title i').style.color = '#264de4';
            htmlCode.textContent = currentCSS;
        } else if (item.textContent.includes('script.js')) {
            document.querySelector('.editor-header .editor-title span').textContent = 'script.js';
            document.querySelector('.editor-title i').className = 'fab fa-js';
            document.querySelector('.editor-title i').style.color = '#f0db4f';
            htmlCode.textContent = currentJS;
        }
        
        updateHighlighting();
    });
});

// Run button functionality - supports all languages
runBtn.addEventListener('click', () => {
    // Clear previous output
    outputContent.innerHTML = '';
    
    if (currentLanguage === 'html') {
        // Create an iframe for HTML output
        const iframe = document.createElement('iframe');
        iframe.className = 'output-frame';
        iframe.id = 'output-frame';
        outputContent.appendChild(iframe);
        
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        
        // Write HTML content to iframe
        const combinedHTML = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Output</title>
                <style>${currentCSS}</style>
            </head>
            <body>
                ${currentHTML}
                <script>${currentJS}</script>
            </body>
            </html>
        `;
        
        iframeDoc.open();
        iframeDoc.write(combinedHTML);
        iframeDoc.close();
    } else {
        // For non-HTML languages, create a preformatted output
        const pre = document.createElement('pre');
        pre.className = 'output-text';
        pre.style.padding = '15px';
        pre.style.margin = '0';
        pre.style.fontFamily = 'Consolas, monospace';
        pre.style.whiteSpace = 'pre-wrap';
        pre.style.wordBreak = 'break-word';
        
        // Get the expected output for this language
        const outputText = languageOutputs[currentLanguage] || 
                           `No output available for ${getLangName(currentLanguage)}`;
        
        pre.textContent = outputText;
        outputContent.appendChild(pre);
    }
});

// Clear output
clearOutputBtn.addEventListener('click', () => {
    outputContent.innerHTML = '<div class="output-placeholder">Click on RUN button to see the output</div>';
});

// Language selection from dropdown
document.querySelectorAll('.lang-option').forEach(option => {
    option.addEventListener('click', () => {
        const lang = option.getAttribute('data-lang');
        langBtn.innerHTML = `
            <i class="${getLangIcon(lang)}"></i> ${getLangName(lang)} 
            <i class="fas fa-chevron-down"></i>
        `;
        langDropdown.classList.remove('active');
        
        // Set the default template for the selected language
        if (lang === 'html') {
            document.querySelector('.file-list').style.display = 'block';
            document.querySelector('.tabs').style.display = 'flex';
            htmlCode.textContent = codeTemplates.html;
            currentHTML = codeTemplates.html;
            currentCSS = codeTemplates.css;
            currentJS = codeTemplates.js;
        } else {
            document.querySelector('.file-list').style.display = 'none';
            document.querySelector('.tabs').style.display = 'none';
            document.querySelector('.editor-header .editor-title span').textContent = 
                getFileName(lang);
            document.querySelector('.editor-title i').className = getLangIcon(lang);
            htmlCode.textContent = codeTemplates[lang] || `// ${getLangName(lang)} code`;
        }
        
        currentLanguage = lang;
        updateHighlighting();
    });
});

// Language selection from cards
languageCards.forEach(card => {
    card.addEventListener('click', () => {
        const lang = card.getAttribute('data-lang');
        langBtn.innerHTML = `
            <i class="${getLangIcon(lang)}"></i> ${getLangName(lang)} 
            <i class="fas fa-chevron-down"></i>
        `;
        
        // Set the default template for the selected language
        if (lang === 'html') {
            document.querySelector('.file-list').style.display = 'block';
            document.querySelector('.tabs').style.display = 'flex';
            htmlCode.textContent = codeTemplates.html;
            currentHTML = codeTemplates.html;
            currentCSS = codeTemplates.css;
            currentJS = codeTemplates.js;
        } else {
            document.querySelector('.file-list').style.display = 'none';
            document.querySelector('.tabs').style.display = 'none';
            document.querySelector('.editor-header .editor-title span').textContent = 
                getFileName(lang);
            document.querySelector('.editor-title i').className = getLangIcon(lang);
            htmlCode.textContent = codeTemplates[lang] || `// ${getLangName(lang)} code`;
        }
        
        currentLanguage = lang;
        updateHighlighting();
    });
});

// Format button functionality
formatBtn.addEventListener('click', () => {
    // For demo purposes, we'll just show an alert
    alert('Code formatted! In a real implementation, this would use a code formatter library.');
});

// Copy button functionality
copyBtn.addEventListener('click', () => {
    const range = document.createRange();
    range.selectNode(htmlCode);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);
    document.execCommand('copy');
    
    // Show copied notification
    const originalText = copyBtn.innerHTML;
    copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
    setTimeout(() => {
        copyBtn.innerHTML = originalText;
    }, 2000);
});

// Clear button functionality
clearBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear the editor?')) {
        htmlCode.textContent = '';
        updateCodeStorage();
        updateHighlighting();
    }
});

// Download button functionality
document.querySelector('.btn-download').addEventListener('click', () => {
    const currentTab = document.querySelector('.tab.active').textContent.trim();
    let content, filename;
    
    if (currentTab === 'index.html') {
        content = currentHTML;
        filename = 'index.html';
    } else if (currentTab === 'styles.css') {
        content = currentCSS;
        filename = 'styles.css';
    } else if (currentTab === 'script.js') {
        content = currentJS;
        filename = 'script.js';
    } else {
        content = htmlCode.textContent;
        filename = getFileName(currentLanguage);
    }
    
    downloadFile(content, filename);
});

// Fullscreen functionality
fullscreenBtn.addEventListener('click', () => {
    // Create fullscreen container
    const fullscreenContainer = document.createElement('div');
    fullscreenContainer.className = 'fullscreen';
    
    // Create iframe for fullscreen output
    const iframe = document.createElement('iframe');
    iframe.className = 'fullscreen-frame';
    
    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-fullscreen';
    closeBtn.innerHTML = '<i class="fas fa-times"></i>';
    
    // Add elements to container
    fullscreenContainer.appendChild(iframe);
    fullscreenContainer.appendChild(closeBtn);
    
    // Add to document
    document.body.appendChild(fullscreenContainer);
    
    // Write content to iframe
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    
    if (currentLanguage === 'html') {
        // Write HTML content to iframe
        const combinedHTML = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Fullscreen Output</title>
                <style>${currentCSS}</style>
            </head>
            <body>
                ${currentHTML}
                <script>${currentJS}</script>
            </body>
            </html>
        `;
        
        iframeDoc.open();
        iframeDoc.write(combinedHTML);
        iframeDoc.close();
    } else {
        // For non-HTML languages, create a simple output page
        const outputHTML = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Fullscreen Output</title>
                <style>
                    body { 
                        font-family: monospace; 
                        background: #f0f0f0; 
                        padding: 20px; 
                    }
                    pre { 
                        background: white; 
                        padding: 15px; 
                        border-radius: 4px; 
                    }
                </style>
            </head>
            <body>
                <h1>${getLangName(currentLanguage)} Output</h1>
                <pre>${languageOutputs[currentLanguage] || 'No output available'}</pre>
            </body>
            </html>
        `;
        
        iframeDoc.open();
        iframeDoc.write(outputHTML);
        iframeDoc.close();
    }
    
    // Close button functionality
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(fullscreenContainer);
    });
});

// Update code when typing
htmlCode.addEventListener('input', () => {
    updateCodeStorage();
    updateHighlighting();
});

// Update code storage
function updateCodeStorage() {
    const currentTab = document.querySelector('.tab.active').textContent.trim();
    
    if (currentTab === 'index.html') {
        currentHTML = htmlCode.textContent;
    } else if (currentTab === 'styles.css') {
        currentCSS = htmlCode.textContent;
    } else if (currentTab === 'script.js') {
        currentJS = htmlCode.textContent;
    }
}

// Helper functions
function getLangIcon(lang) {
    const icons = {
        html: 'fab fa-html5',
        python: 'fab fa-python',
        c: 'fas fa-c',
        cpp: 'fas fa-plus',
        php: 'fab fa-php',
        java: 'fab fa-java',
        javascript: 'fab fa-js',
        ruby: 'fas fa-gem',
        swift: 'fab fa-swift',
        typescript: 'fas fa-code',
        go: 'fas fa-code',
        rust: 'fas fa-code',
        kotlin: 'fas fa-code',
        dart: 'fas fa-code',
        scala: 'fas fa-code'
    };
    return icons[lang] || 'fas fa-code';
}

function getLangName(lang) {
    const names = {
        html: 'HTML',
        python: 'Python',
        c: 'C',
        cpp: 'C++',
        php: 'PHP',
        java: 'Java',
        javascript: 'JavaScript',
        ruby: 'Ruby',
        swift: 'Swift',
        typescript: 'TypeScript',
        go: 'Go',
        rust: 'Rust',
        kotlin: 'Kotlin',
        dart: 'Dart',
        scala: 'Scala'
    };
    return names[lang] || lang;
}

function getFileName(lang) {
    const files = {
        python: 'main.py',
        c: 'main.c',
        cpp: 'main.cpp',
        php: 'index.php',
        java: 'Main.java',
        javascript: 'script.js',
        ruby: 'main.rb',
        swift: 'main.swift',
        typescript: 'app.ts',
        go: 'main.go',
        rust: 'main.rs',
        kotlin: 'Main.kt',
        dart: 'main.dart',
        scala: 'Main.scala'
    };
    return files[lang] || `main.${lang}`;
}

function downloadFile(content, filename) {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function updateHighlighting() {
    const currentTab = document.querySelector('.tab.active').textContent.trim();
    const langMap = {
        'index.html': 'language-html',
        'styles.css': 'language-css',
        'script.js': 'language-javascript',
        'python': 'language-python',
        'c': 'language-c',
        'cpp': 'language-cpp',
        'java': 'language-java',
        'php': 'language-php',
        'ruby': 'language-ruby',
        'swift': 'language-swift',
        'typescript': 'language-typescript'
    };
    
    const langClass = langMap[currentTab] || langMap[currentLanguage] || 'language-html';
    
    // Update code element class for highlighting
    htmlCode.className = langClass;
    
    // Highlight the code
    hljs.highlightElement(htmlCode);
}

// Initialize highlighting
updateHighlighting();